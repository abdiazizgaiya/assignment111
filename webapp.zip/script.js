function validateRegister() {
    let email = document.getElementById("email").value;
    let pass = document.getElementById("password").value;
    let confirm = document.getElementById("confirmPassword").value;
    let regex = /^(?=.*\d)(?=.*[A-Z]).{8,}$/;

    if (!regex.test(pass)) {
        alert("Password must be at least 8 characters long, contain one uppercase letter and one number.");
        return false;
    }
    if (pass !== confirm) {
        alert("Passwords do not match.");
        return false;
    }
    return true;
}

function validateLogin() {
    let email = document.getElementById("loginEmail").value;
    let pass = document.getElementById("loginPassword").value;
    if (!email || !pass) {
        alert("All fields are required.");
        return false;
    }
    return true;
}